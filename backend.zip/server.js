const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
  },
});

let users = new Set();

io.on("connection", (socket) => {
  let nickname = "뎃붕이" + Math.floor(Math.random() * 10000);

  socket.on("set_nickname", (name) => {
    if (!name || users.has(name)) {
      socket.emit("nickname_confirmed", nickname);
    } else {
      nickname = name;
      users.add(name);
      socket.emit("nickname_confirmed", name);
    }
  });

  socket.on("message", (msg) => {
    io.emit("message", { name: nickname, msg });
  });

  socket.on("disconnect", () => {
    users.delete(nickname);
  });
});

server.listen(3000, () => {
  console.log("Server running on port 3000");
});